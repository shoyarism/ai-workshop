# Pipeline Tools & Toolchain Integration

This directory details the execution engines and CLI toolchains used by the Vox-Inspired Explainer Video Production Agent.

---

## 1. Speech Synthesis & Audio Alignment

### Engine A: Local Edge Neural TTS (`edge-tts`)
- Free, high-fidelity neural speech synthesis with Indonesian and English models.
- Indonesian voices: `id-ID-ArdiNeural` (Male, authoritative newsroom tone) and `id-ID-GadisNeural` (Female).
- Outputs sentence/word boundary events with millisecond timestamps.

```bash
uv run edge-tts --voice id-ID-ArdiNeural --text "Halo semua..." --write-media voiceover.mp3 --write-subtitles subtitles.vtt
```

### Engine B: ElevenLabs Studio API
- Commercial ultra-natural voice cloning and studio narrator voices.
- Used when custom voice character or premium cinematic presence is required.

---

## 2. Audio Post-Processing & Master Ducking (`ffmpeg`)

Ducks background documentary music beneath voiceover dialogue:

```bash
ffmpeg -y \
  -i bgm.mp3 \
  -i voiceover.mp3 \
  -filter_complex "[0:a]volume=0.18[bgm_ducked];[1:a]volume=1.0[voice];[bgm_ducked][voice]amix=inputs=2:duration=longest" \
  -c:a aac -b:a 192k audio_master.mp3
```

---

## 3. Motion Graphics Rendering Engines

### Engine A: Direct-Pipe Headless Edge / Chromium + Playwright
- **Advantage:** Zero npm build step, 100% deterministic timecode seeking via `window.seekToTime(t)`, pure web standards (HTML5/CSS3/GSAP 3.12).
- **Architecture:** Playwright captures 1080p frame buffers and pipes directly into `ffmpeg` stdin (`-f image2pipe -vcodec mjpeg`).
- **Telemetry:** Reaches ~25-28 fps on modern multi-core Windows systems (real-time rendering speed).

### Engine B: Remotion Framework (React Native Video)
- React-based programmatic video rendering.
- Enables component reuse, parameterized props, and frame-accurate canvas drawing.
- Best suited for large-scale enterprise rendering farms.

---

## 4. Anti-Slop QC Verification Tools
- Contrast Checker: Verifies WCAG AAA contrast ratio ($\ge 7.0:1$) between `#121417` text and `#F5F2EA` paper.
- Timing Linter: Verifies that audio duration and animation timeline duration match within $\pm 0.05$ seconds.
